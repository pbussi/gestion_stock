<?php $__env->startSection('content'); ?>
  <script src=<?php echo e(asset('/vendor/jquery/jquery.min.js')); ?>></script>
        <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Ventas no cumplidas por falta de Stock</h1>
          <p class="mb-4 m-0 font-weight-bold text-info"> <?php if($valor=="2"): ?>
                              <b><?php echo e(date('d-m-Y', strtotime($desde))); ?> </b>hasta <b><?php echo e(date('d-m-Y', strtotime($hasta))); ?></b> </p>
                            <?php else: ?>
                              <b>HISTORICO </b></p>
                            <?php endif; ?>
       
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h5 class="m-0 font-weight-bold text-info"> </h5>
            </div>
            <?php $r=0;$difSubtot=0;?>
            <div class="card-body">
            
                    <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto=>$enviados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <p class="text-info"><b><?php echo e($producto); ?></b></p>
                      <div class="table-responsive">
                      <table class="table small" id="dataTableQ" width="70%" cellspacing="0">
                      <thead>
                      <tr>
                        <th scope="col" width="20%">Fecha</th>
                        <th scope="col" width="30%">Comprobante</th>
                        <th scope="col" width="40%">Razón Social</th>
                        <th scope="col" width="40%" style="text-align: center">Pedido</th>  
                        <th scope="col" width="30%" style="text-align: center">Remitido </th>   
                        <th scope="col" width="30%" style="text-align: center">Diferencia </th> 
                        <th scope="col" width="30%" style="text-align: right">U.M.</th>  
                      </tr>
                    </thead>
                     <tbody>
                      <?php $__currentLoopData = $enviados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                         <td><?php echo e(date("d/m/Y",strtotime($r['fecha_venta']))); ?></td>
                         <td><?php echo e($r['remito']); ?></td>
                          <td><?php echo e($r['cliente']); ?></td>
                          <td style="text-align: right"><?php echo e($r['cant_pedida']); ?></td>
                          <td style="text-align: right"><?php echo e($r['cant_enviada']); ?></td>
                          <td style="text-align: right"><?php echo e(number_format($r['cant_pedida']-$r['cant_enviada'],2,".",",")); ?></td>
                          <td><?php echo e($r['unidad_medida']); ?></td>  
                          <?php $difSubtot=$difSubtot+ number_format($r['cant_pedida']-$r['cant_enviada'],2,".",","); ?>                                    
                      </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody> 
                     <tr><td colspan="6" style="text-align:right;">Ventas Perdidas de <?php echo e($producto); ?>  : <b><?php echo number_format($difSubtot,2,".",","); ?></b></td></tr>
                </table>
              </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
              
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/ventas_no_cumplidas.blade.php ENDPATH**/ ?>