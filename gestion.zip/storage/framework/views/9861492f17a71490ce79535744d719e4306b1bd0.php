<?php $__env->startSection('content'); ?>
  <script src=<?php echo e(asset('/vendor/jquery/jquery.min.js')); ?>></script>
        <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Ranking de Venta por Productos</h1>
          <p class="mb-4 m-0 font-weight-bold text-info"> <?php if($listado=="2"): ?>
                              <b><?php echo e(date('d-m-Y', strtotime($desde))); ?> </b>hasta <b><?php echo e(date('d-m-Y', strtotime($hasta))); ?></b> </p>
                            <?php else: ?>
                              <b>HISTORICO </b></p>
                            <?php endif; ?>
       
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h5 class="m-0 font-weight-bold text-info"> </h5>
            </div>
            <?php $r=0;?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table small" id="dataTableQ" width="70%" cellspacing="0">
                  <thead>
                    <tr>
                        <th scope="col" width="20%">Ranking</th>
                         <th scope="col" width="20%">Código</th>
                          <th scope="col" width="50%">Nombre Producto</th>
                          <th scope="col" width="50%">U.M.</th>
                         <th scope="col" width="30%" style="text-align: right">Cantidad Vendida </th>         
                    </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><b><?php $r=$r+1; echo $r ?></b></td>
                      <td><?php echo e($rank->productos_id); ?></td>
                       <td><a href="<?php echo e(url('/movimiento_producto',$rank->productos_id)); ?>">
                        <?php echo e($rank->nombre); ?></a></td>
                        <td><?php echo e($rank->unidad_medida); ?></td>
                      <td style="text-align: right">  
                        <?php echo e($rank->total_producto); ?>

                     </td>                                       
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  </tbody>
                 
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/estadistica_productos.blade.php ENDPATH**/ ?>