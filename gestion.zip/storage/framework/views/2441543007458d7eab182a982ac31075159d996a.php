<?php $__env->startSection('content'); ?>
 
 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Stock Actual de Productos</h1>

         <div class="card-header py-3">
              <h6 class="m-0 text-info font-weight-bold text-uppercase mb-4"><b> Saldos al <?php echo e(date('d-m-Y')); ?> </b>

               <a href="<?php echo e(url('saldos_a_fecha_pdf')); ?>"  class=" btn btn-warning btn-icon-split float-right" style="margin-left: 10px;">
                    <span class="icon text-white-50">
                      <i class="fas fa-print"></i>
                    </span>
                    <span class="text">Descargar PDF</span>
                  </a>
              
              </h6>
            </div>

          <p class="mb-4">En todos los depósitos administrados por el sistema</p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            
            <div class="card-body">
             <div class="table-responsive">
             <table class="table  small" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                 <th scope="col">Marca</th>
                <th scope="col">U.M.</th>
                <th scope="col"  style="text-align:center;">Saldo</th>
              </tr>
            </thead>
           <tbody>
            <?php $acum=0; ?>
            <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>

              <th scope="row"><?php echo e($s->id_producto); ?></th>
              <td><a href=""> <b><?php echo e($s->nombre); ?></b></a></td>
               <td><?php echo e($s->marca); ?></td>
              <td><?php echo e($s->unidad_medida); ?></td>
              <td style="text-align:right"> <?php echo e(number_format($s->cantidad,2,",",".")); ?></td>    
              <?php $acum=$acum + $s->cantidad; ?>          
                     
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <thead>
             <tr style="height: 50px;">
                        <td colspan=7  style="text-align:right" >CANTIDAD TOTAL: <b>  <?php echo number_format($acum,2,",","."); ?></b></td></tr>
            <thead>
          </tbody>
        </table>
      </div>
    </div>
</div>
        <!-- /.container-fluid -->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/saldos_a_fecha.blade.php ENDPATH**/ ?>