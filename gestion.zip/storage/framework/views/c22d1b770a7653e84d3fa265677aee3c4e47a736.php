<?php $__env->startSection('content'); ?>
  <script src=<?php echo e(asset('/vendor/jquery/jquery.min.js')); ?>></script>
        <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Listado de Pedidos</h1>
          <p class="mb-4">Gestion de ventas</p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Pedidos en Sistema</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped small" id="dataTableQ" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th scope="col">Numero</th>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Estado</th>         
                        <th class="w-10">Accion</th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><a href="<?php echo e(url('/venta_gestion',$p->id)); ?>">
                        <?php echo "REM".str_pad($p->id,6,"0", STR_PAD_LEFT); ?>

                      </a></td>
                      <td class="date"><?php echo e(date('d-m-Y', strtotime($p->fecha))); ?></td>
                      <td class="text-uppercase"><?php echo e($p->razon_social); ?></td>     
                      <td class=""><?php if( $p->estado==0 ): ?> Abierto <?php else: ?> En Preparacion <?php endif; ?> </td>   
                     
                      <td class="w-10"> 
                      <a href="#" class="float-right">
                        <span class="icon">
                          <i class="fas fa-trash"></i>
                        </span>
                      </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/pedidos_lista.blade.php ENDPATH**/ ?>