<?php $__env->startSection('content'); ?>
 
<div class="container-fluid">
       <h1 class="h3 mb-2 text-gray-800">Gestion de lista de Precios</h1>

         <div class="card-header py-3">
              <h6 class="m-0 text-info font-weight-bold text-uppercase mb-4"><b> <?php echo e($lista->nombre); ?> </b>

                  <a href="<?php echo e(url('lista_pdf',$lista->id)); ?>"  class=" btn btn-warning btn-icon-split float-right" style="margin-left: 10px;">
                    <span class="icon text-white-50">
                      <i class="fas fa-print"></i>
                    </span>
                    <span class="text">Descargar PDF</span>
                  </a>
              
              </h6>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">
               <div class="table-responsive">
                  <form method=post  action="<?php echo e(url('/lista_gestion')); ?>" id=lista_gestion>
                     <?php echo csrf_field(); ?>
                     <table class="table-bordered table-striped small" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nombre</th>
                             <th scope="col">Marca</th>
                            <th scope="col">U.M.</th>
                            <th scope="col">Tipo</th>
                            <th scope="col" style="text-align:right;">$ Precio</th>
                          </tr>
                        </thead>
                         <tbody>
                          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($s->codigo); ?></th>
                                <td> <b><?php echo e($s->nombre); ?></b></td>
                                 <td><?php echo e($s->marca); ?></td>
                                <td><?php echo e($s->unidad_medida); ?></td>  
                                 <td><?php echo e($s->tipo); ?></td>  
                                <td align=right>
                                    <input style="text-align: right;<?php
                                        if ($s->precio==0){
                                          echo "background-color: #40e3a8;";
                                        } else {echo "background-color: white;";}
                                    ?>" type=text size=7 name=precios[<?php echo e($s->id); ?>] value='<?php echo e(number_format($s->precio,2,",",".")); ?>'>
                                   </td>            
                           </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                          </tbody>
                    </table>
                    <input type=hidden name=lista_id value=<?php echo e($lista->id); ?>>
                    <a href="#" onclick="document.getElementById('lista_gestion').submit();" class="btn btn-success btn-icon-split float-right">
                     <span class ="icon text-white-50">
                     <i class="fas fa-archive"></i>
                      </span>
                      <span class="text">Guardar</span></a>



                 
                </form>
            <br><br>
              
                 <form method=post  id=lista_gestion_agregar action="<?php echo e(url('/lista_gestion_agregar')); ?>">
                     <?php echo csrf_field(); ?>
                     <label for="tipo_prod">Incorporar productos</label><BR>
                     <select class="form-control float-left"  name=item style="width: 50%">
                        <?php $__currentLoopData = $faltantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($f->id); ?>"> <?php echo e($f->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type=hidden name=lista_id value=<?php echo e($lista->id); ?>>
                    <a href="#" onclick="document.getElementById('lista_gestion_agregar').submit();" class="btn btn-info btn-icon-split float-left" style="margin-top: 0px;">
                     <span class ="icon text-white-50">
                     <i class="fas fa-plus"></i>
                      </span>
                      <span class="text">Agregar</span></a>
                 </form>  <br><Br>
               </div>
          </div>
      </div>

   </div>       
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/lista_gestion.blade.php ENDPATH**/ ?>