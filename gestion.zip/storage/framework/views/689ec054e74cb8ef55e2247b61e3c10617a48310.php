<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Stock actual de productos</h1>
          <p class="mb-4"> por Agrupacion </p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 text-info font-weight-bold text-uppercase mb-4"><b> <?php echo e($titulo); ?></b>

             <a href="<?php echo e(url('stock_por_agrupacion_pdf',$grupo)); ?>"  class=" btn btn-warning btn-icon-split float-right" style="margin-left: 10px;">
                    <span class="icon text-white-50">
                      <i class="fas fa-print"></i>
                    </span>
                    <span class="text">Descargar PDF</span>
                  </a>
              
              </h6>
            </div>

            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped small" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Tipo</th>
                        <th>U.M.</th>
                        <th>Saldo</th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $saldos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e($s->codigo); ?></th>
                      
                      <td><a href="<?php echo e(url('/movimiento_producto',$s->id_producto)); ?>"><?php echo e($s->nombre); ?></a></td>
                      <td><?php echo e($s->marca); ?></td>
                      <td><?php echo e($s->tipo_producto); ?></td>
                      <td><?php echo e($s->unidad_medida); ?></td>
                      <td><?php echo e($s->cantidad); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  </tbody>
                </table>
              </div>
        
     


            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/stock_agrupacion.blade.php ENDPATH**/ ?>