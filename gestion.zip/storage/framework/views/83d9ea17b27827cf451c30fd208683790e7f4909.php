<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Ventas por Cliente </h1>
          <p class="mb-4"></p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Cliente a evaluar</h6>
            </div>
            <div class="card-body">
 <form class="user" action="<?php echo e(url('/pedidos_seleccion_cliente')); ?>" id=pedidos_seleccion_cliente method=POST>
      <?php echo csrf_field(); ?>
        <div class="form-group row">
            <div class="col-sm-6 mb-3 mb-sm-0">
               <label for="fecha_mov">Seleccione Cliente: </label>
               <select class="form-control text-uppercase"  name=cliente>
                 <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option  value=<?php echo e($c->id); ?> ><?php echo e($c->razon_social); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

      
       <div class="form-group row">
            <div class="col-sm-3 mb-3 mb-sm-0">
                <label for="fecha_mov">Desde</label>
                <input class="form-control" type="date" name=fecha_desde value="<?php echo e(date('d-m-Y')); ?>">
            </div>
            <div class="col-sm-3">
              <label for="fecha_mov">Hasta</label>
                <input class="form-control" type="date" name=fecha_hasta value="<?php echo e(date('d-m-Y')); ?>">
            </div>       
        </div>
              <a href="#"  onclick="document.getElementById('pedidos_seleccion_cliente').submit();" class="btn btn-success btn-icon-split">
               <span class ="icon text-white-50">
                          <i class="fas fa-check-double"></i>
               </span>
               <span class="text">Consultar</span>
              </a>
            </div>

     

            
            
        </div>
      
    </form>

            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/pedidos_seleccion_cliente.blade.php ENDPATH**/ ?>