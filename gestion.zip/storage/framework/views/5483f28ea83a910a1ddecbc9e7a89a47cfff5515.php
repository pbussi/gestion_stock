<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Movimientos</h1>
          <p class="mb-4">Entradas y Salidas de Materias Primas e Insumos</p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Transferencia entre Depositos de Insumos y Materias Primas </h6>
            </div>
            <div class="card-body">
 <form class="user" action="<?php echo e(url('/movimiento_mp_salida_seleccion')); ?>" id=movimiento_mp_salida_seleccion method=POST>
      <?php echo csrf_field(); ?>
         <div class="form-group row">
            <div class="col-sm-0 mb-0 mb-sm-0">
            </div>
            <div class="col-sm-3">
              <input class="form-control" type="text" placeholder="Buscar Productos" name=buscar>
            </div>
            <div class="col-sm-3 mb-3 mb-sm-0">
              <a href="#"  onclick="document.getElementById('movimiento_mp_salida_seleccion').submit();" class="btn btn-success btn-icon-split">
               <span class ="icon text-white-50">
                          <i class="fas fa-check-double"></i>
               </span>
               <span class="text">Buscar</span>
              </a>
            </div>
            <div class="col-sm-6 mb-3 mb-sm-0">
              
                 <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url('/movimiento_mp_salida',$p->id)); ?>" ><?php echo e($p->nombre); ?> </a></li>    
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            
        </div>
      
    </form>

            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/movimiento_mp_salida_seleccion.blade.php ENDPATH**/ ?>