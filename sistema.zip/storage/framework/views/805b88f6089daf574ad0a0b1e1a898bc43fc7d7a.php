<?php $__env->startSection('content'); ?>
        <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800"><?php echo e($titulos[0]); ?></h1>
          <p class="mb-4"><?php echo e($titulos[1]); ?></p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary"><?php echo e($titulos[2]); ?>

<a href="<?php echo e(url('/productos_saldos_pdf')); ?>?tipo=<?php echo Request::path(); ?>" class=" btn btn-warning btn-icon-split float-right" style="margin-left: 10px;">
                    <span class="icon text-white-50">
                      <i class="fas fa-print"></i>
                    </span>
                    <span class="text">Saldos</span>
                  </a>
              <a href="<?php echo e(url('/producto_nuevo')); ?>"  class=" btn btn-success btn-icon-split float-right">
                    <span class="icon text-white-50">
                      <i class="fas fa-check-double"></i>
                    </span>
                    <span class="text">Crear nuevo</span>
                  </a>
                 
           </h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped small" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                        <th>Foto</th>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>U.M.</th>
                        <th>Tipo</th>
                        <th>Precio Costo</th>
                        <th>Lleva Stock</th>
                        <th>Stock Minimo</th>
                        <th>Stock Maximo</th>
                        <th>Punto Pedido</th>
                        <th class="w-10"></th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><small><?php echo e($p->codigo); ?></small></th>
                      <td>
                        <?php if($p->imagen != ''): ?>
                        <img src='data:image/JPG;base64,<?php echo e(base64_encode($p->imagen)); ?>' width=60px;/>
                        <?php endif; ?>
                      </td>
                      <td class="text-uppercase" style="width:30%"><a href="<?php echo e(url('/movimiento_producto',$p->id)); ?>"><B><?php echo e($p->nombre); ?></B></a></td>
                      <td  style="width:5%"><?php echo e($p->marca); ?></td>
                      <td><?php echo e($p->unidad_medida); ?></td>
                      <td><?php echo e($p->tipo_nombre); ?></td>
                      <td style="text-align: right;">$<?php echo e($p->precio_costo); ?></td> 
                      <td>
                        <?php if($p->lleva_stock === 1): ?>
                        SI
                        <?php else: ?>
                        NO
                        <?php endif; ?>
                      </td>
                      <td><?php echo e($p->stock_minimo); ?></td>
                      <td><?php echo e($p->stock_maximo); ?></td>
                      <td><?php echo e($p->punto_pedido); ?></td>
                      <td class="w-10" style="width:20%"> 
                        <a href="<?php echo e(url('/producto_edit',$p->id)); ?>" class="float-left">
                        <span class="icon">
                          <i class="fas fa-edit">  &nbsp;  &nbsp;</i>
                        </span>
                        </a>
                       
                        <a href="<?php echo e(url('/productos')); ?>?borrar=<?php echo e($p->id); ?>" class="float-left">
                        <span class="icon">
                          <i class="fas fa-trash"></i> 
                        </span>
                      </a> 
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/productos.blade.php ENDPATH**/ ?>