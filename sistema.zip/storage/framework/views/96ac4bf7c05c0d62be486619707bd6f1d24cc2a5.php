<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Movimientos</h1>
          <p class="mb-4">Descarte de Materiales</p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary"><b> <?php echo e($producto->nombre); ?></b></h6>
            </div>
      <div class="card-body">
 <form class="user" action="<?php echo e(url('/movimiento_descarte')); ?>" id=movimiento_descarte method=POST>
      <?php echo csrf_field(); ?>
        <input type=hidden name=id value="<?php echo e($producto->id); ?>">

        <div class="form-group row ">
            <div class="col-sm-3 mb-3 mb-sm-0">
               <label for="fecha_mov">Fecha de Salida</label>
              <input class="form-control" type="date" name=fecha_movimiento id=fecha_mov value="<?php echo e(date('Y-m-d')); ?>">
            </div>

        </div>

          <div class="form-group row">
 

              <div class="col-sm-12 mb-6 mb-sm-0">  
                <br>
                <label>Seleccione el deposito y lote a descartar</label>
                <table class="table table-striped dataTable">
                  <thead>
                    <tr>
                    <Th> </Th>
                    <th>DEPOSITO</th>
                      <th>LOTE Nro.</th>
                      <th>VENCIMIENTO </th>
                      <th>SALDO</th>
                     
                   </tr>
                  </thead>
                   <?php $primero=true; ?>
                <?php $__currentLoopData = $saldos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><input type="radio" name=stock_deposito <?php if ($primero){$primero=false; echo "checked";} ?> value=<?php echo e($p->id_lote_mp); ?>-<?php echo e($p->id_lote_produccion_id); ?>-<?php echo e($p->id_deposito); ?>-<?php echo e($p->saldo); ?>></td>
                    <td><?php echo e($p->nombre_deposito); ?></td>
                    <td><?php echo e($p->numero_lote); ?></td> 
                     <td><?php echo e(date('d-m-Y', strtotime($p->vencimiento))); ?></td> 
                    <td class="text-info"> <?php echo e($p->saldo); ?> <?php echo e($producto->unidad_medida); ?></td>        
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>

              </div>
        </div>

      <div class="form-group row"> 
          <br><br>
          <div class="col-sm-3 mb-3 mb-sm-0">
               <label for="movimiento_cantidad">Cantidad a Eliminar</label>
               <input class="form-control text-danger" type="text" name=movimiento_cantidad style="font-weight: bold;">
          </div>
          <div class="col-sm-2 mb-3 mb-sm-0">
              <label for="unidad_medida">Unidad de Medida</label>   
               <input class="form-control" type="text" name=unidad_medida readonly="readonly" placeholder="<?php echo e($producto->unidad_medida); ?>">
          </div>   
     </div>
      <div class="form-group row"> 

          <div class="col-sm-5 mb-3 mb-sm-0"> 
                <label for="stkmax">Observaciones</label>
                <input class="form-control" type="textarea" placeholder=""  name=movimientos_observaciones>
          </div>

             
         

       </div>

       <div class="form-group row"> 
            <div class="col-sm-4 mb-3 mb-sm-0">
              <a href="#"  onclick="document.getElementById('movimiento_descarte').submit();" class="btn btn-success btn-icon-split">
               <span class ="icon text-white-50">
                          <i class="fas fa-check-double"></i>
               </span>
               <span class="text">Crear movimiento</span>
              </a>
            </div>
          </div>     
    </form>

            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/movimiento_descarte.blade.php ENDPATH**/ ?>