<?php $__env->startSection('content'); ?>
  <script src=http://localhost/proyecto/gestion_stock/public/vendor/jquery/jquery.min.js></script>
  <div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Lote Producción  Nro. <B> <?php echo "PROD".str_pad($lote->id,6,"0", STR_PAD_LEFT); ?></B> </h1>


    <p class="mb-4">Gestion de ingredientes de la produccion</p>
      <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0  text-primary"> Fecha:  <?php echo e($lote->fecha); ?> </h6>
           
        </div>
      </div>
    <ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link " href="<?php echo e(url('/lotes_produccion_gestion',$lote->id)); ?>">Insumos utilizados</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" href="<?php echo e(url('/lotes_produccion_gestion_terminados',$lote->id)); ?>">Productos terminados</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/lotes_produccion_gestion_info',$lote->id)); ?>">Información del Lote</a>
  </li>
  
</ul>  
        <div class="card-body">
         <div class="table-responsive">
          <table class="table table-bordered small" id="xxdataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th scope="col">Codigo</th>
              <th scope="col">nombre</th>
              <th scope="col">Unidad de Medida</th>
              <th scope="col">Cantidad</th>
              <th scope="col">Accion</th>
            </tr>
          </thead>
       <tbody>
        <?php $__currentLoopData = $terminados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($t->id); ?></td>
            <td> <?php echo e($t->nombre); ?></td>
            <td><?php echo e($t->unidad_medida); ?></td>
            <td><?php echo e($t->cantidad); ?></td>
            <td class="w-10"> 
               <?php if($lote->estado==1): ?>
                 <a href="<?php echo e(url('/lotes_produccion_gestion_terminados',$lote->id)); ?>?borrar=<?php echo e($t->pt_id); ?>" class="float-left">
                 <span class="icon"><i class="fas fa-trash"></i></span></a>
              <?php endif; ?>
             </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

    

<?php if($lote->estado==1): ?>
<form action="<?php echo e(url('/lotes_produccion_gestion_terminados',$lote->id)); ?>" id=nuevo_sabor method=POST>
<div class="form-group row">
      <?php echo csrf_field(); ?>
        <div class="col-sm-3 mb-3 mb-sm-0">
          <label for="lote_numero">Producto</label>
             <select class="form-control"  name=producto id=producto>
               <option value=0 >Elija producto</option>
               <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($p->id); ?>><?php echo e($p->nombre); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-1 mb-3 mb-sm-0">
          <label for="unidad_medida">Cantidad</label>   
          <input class="form-control" type="text" name=cantidad id=cantidad >
        </div>
        <div class="col-sm-1 mb-3 mb-sm-0">
          <label for="unidad_medida"></label>
            <a href="#"  onclick="
                  if (!(parseFloat($('#cantidad').val())>0)){
                    alert('Ingrese cantidad');
                    return;
                  }
                    document.getElementById('nuevo_sabor').submit(); "
                  class="btn btn-success btn-icon-split" style="margin-top: 7px;">
            <span class ="icon text-white-50">
                <i class="fas fa-check-double"></i>
            </span>
            <span class="text">Agregar</span></a>
        </div>
  
  </div>
</form>      <!-- /.container-fluid -->

<script>
  $(document).ready(function() { 



  });
</script>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/lotes_produccion_gestion_terminados.blade.php ENDPATH**/ ?>