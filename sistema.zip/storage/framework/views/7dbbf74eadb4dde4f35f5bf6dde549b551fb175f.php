<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Vencimiento de Productos</h1>
          <p class="mb-4"> </p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 text-info font-weight-bold text-uppercase mb-4"><b> <?php echo e($titulo); ?></b>
       
              </h6>
            </div>



            <div class="card-body">
              <div class="table-responsive">
                
                    <?php $titulo=""; ?>
                    <?php $__currentLoopData = $saldos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php setlocale(LC_TIME, 'es_ES.UTF-8');$nuevo_titulo=strftime("%B %Y",strtotime($s->vencimiento));?>

                    <?php if ($titulo!=$nuevo_titulo) {
                      if ($titulo!="") {
                          echo "</table>";
                        }
                        echo "<h4 style='margin-top:30px;'>$nuevo_titulo</h4>"; 
                     ?>


                              <table class="table-bordered table-striped small" id="dataTableww" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                              <th scope="col">Codigo</th>
                                <th>Nombre</th>
                                <th>Marca</th>
                                <th>U.M.</th>
                                <th>Tipo</th>
                                <th>Lote</th>
                                <th>Deposito</th>
                                <th>Vencimiento</th>
                                <th>Cantidad</th>
                            </tr>
                          </thead>
                          <tbody>
                    <?php } ?>  
                    <tr>
                      <th><?php echo e($s->codigo); ?></th>
                      
                      <td><a href="<?php echo e(url('/movimiento_producto',$s->codigo)); ?>"><?php echo e($s->nombre); ?></a></td>
                      <td><?php echo e($s->marca); ?></td>
                      <td><?php echo e($s->unidad_medida); ?></td>
                       <td><?php echo e($s->tipo); ?></td>
                        <td><?php echo e($s->lote); ?></td>
                        <td><?php echo e($s->deposito); ?></td>
                         <td <?php if (strtotime("now")>=strtotime($s->vencimiento))
                          echo "class='text-danger'";
                          ?>
                         > <?php echo e(date('d-m-Y', strtotime($s->vencimiento))); ?></td>
                         <td><?php echo e($s->total); ?></td>
                      
                    </tr>

                    <?php $titulo=$nuevo_titulo; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  </tbody>
                </table>
              </div>
        
     


            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/control_vencimientos.blade.php ENDPATH**/ ?>