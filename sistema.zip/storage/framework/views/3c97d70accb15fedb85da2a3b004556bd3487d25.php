<?php $__env->startSection('content'); ?>

 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Edicion de Productos</h1>
          <p class="mb-4">Productos manejados por el sistema</p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-info">  <?php echo e($producto->nombre); ?> </h6>
            </div>
            <div class="card-body">
              

 <form action="<?php echo e(url('/producto_edit')); ?>" id=producto_edit method=POST  enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
         <div class="form-group">
           <input type="hidden" name=id value="<?php echo e($producto->id); ?>">
           <label for="codigo">Codigo de barras</label>
          <input class="form-control"  type="text" placeholder="Codigo (de barra)" name=codigo readonly="readonly" value="<?php echo e($producto->codigo); ?>">
        </div>

         <div class="form-group row">
            <div class="col-sm-6 mb-3 mb-sm-0">
               <label for="nombre">Nombre</label>
              <input class="form-control" type="text"  name=nombre value="<?php echo e($producto->nombre); ?>">
            </div>
            <div class="col-sm-3">
               <label for="marca">Marca</label>
              <input class="form-control" type="text" placeholder="Marca" name=marca value="<?php echo e($producto->marca); ?>">
            </div>
            <div class="col-sm-3 mb-3 mb-sm-0">
               <label for="unidad_medida">Unidad de Medida</label>
               <input class="form-control" type="text" placeholder="Unidad de Medida" name=unidad_medida value="<?php echo e($producto->unidad_medida); ?>">
            </div>
        </div>
         <div class="form-group row">
            <div class="col-sm-6 mb-3 mb-sm-0">
              <label for="llevastk">Lleva Stock?</label>
              <input class="" type="checkbox" placeholder="" name=lleva_stock <?php if($producto->lleva_stock==1): ?> checked <?php endif; ?>>
            </div>
         </div>  
         <div class="form-group row"> 
              <div class="col-sm-6 mb-3 mb-sm-0">
                 <label for="tipo_prod">Tipo de Producto</label>
                 <select class="form-control"  name=tipo_producto_id>
                 <?php $__currentLoopData = $tipos_producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option  <?php if($p->id == $producto->tipo_producto_id): ?> selected="selected" <?php endif; ?>  value=<?php echo e($p->id); ?> ><?php echo e($p->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
          </div>
          <div class="form-group row"> 
              <div class="col-sm-4 mb-3 mb-sm-0">
           
                  <label for="stkmin">Stock Minimo</label>
                  <input class="form-control" type="text" placeholder="" name=stock_minimo value="<?php echo e($producto->stock_minimo); ?>">
              </div>
               <div class="col-sm-4 mb-3 mb-sm-0"> 
                <label for="stkmax">Stock Maximo</label>
                <input class="form-control" type="text" placeholder=""  name=stock_maximo value="<?php echo e($producto->stock_maximo); ?>">
              </div>
              <div class="col-sm-4 mb-3 mb-sm-0"> 
                 <label for="stkmin">Punto de Pedido</label>
                <input class="form-control" type="text" placeholder=""  name=punto_pedido value="<?php echo e($producto->punto_pedido); ?>">
              </div>
            </div>
          <div class="form-group row"> 
            <div class="col-sm-4 mb-3 mb-sm-0">
             <label for="precio_costo">Precio de Costo</label>
             <input class="form-control" type="text" placeholder="Precio de Costo" name=precio_costo value="<?php echo e($producto->precio_costo); ?>">
         </div>
       </div>
        <div class="form-group row"> 
            <div class="col-sm-4 mb-3 mb-sm-0">
              <label for="stkmax">Imagen</label>
             <img src='data:image/JPG;base64,<?php echo e(base64_encode($producto->imagen)); ?>' width=200px;/>
              <input class="form-control" type="file"  name=foto>
            </div>
        </div>
       <div class="form-group row"> 
            <div class="col-sm-4 mb-3 mb-sm-0">
              <a href="#"  onclick="document.getElementById('producto_edit').submit();" class="btn btn-success btn-icon-split">
               <span class ="icon text-white-50">
                          <i class="fas fa-check-double"></i>
               </span>
               <span class="text">Modificar Producto</span>
              </a>
            </div>
          </div>     
    </form>






<!--
<div class="form-group">
        <input type=hidden name=id value="<?php echo e($producto->id); ?>"
         <label for="nombre">Nombre</label>
        <input class="form-control" type="text" placeholder="" style="width:50%;" name=nombre value="<?php echo e($producto->nombre); ?>">
        <br>
        <label for="marca">Marca</label>
        <input class="form-control" type="text" placeholder="" style="width:50%;" name=marca value="<?php echo e($producto->marca); ?>">
    

      </div>
        <a href="#"  onclick="document.getElementById('producto_edit').submit();" class="btn btn-success btn-icon-split">
         <span class ="icon text-white-50">
                      <i class="fas fa-check-double"></i>
                    </span>
                    <span class="text">Modificar</span>
        </a>
     
    </form>
-->
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/producto_edit.blade.php ENDPATH**/ ?>