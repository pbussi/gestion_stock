<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Actualización de Listas de Precios </h1>
          <p class="mb-4">Actualización Global por Lista</p>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Lista a actualizar</h6>
            </div>
            <div class="card-body">
 <form class="user" action="<?php echo e(url('/lista_actualizacion_seleccion')); ?>" id=lista_actualizacion_seleccion method=POST>
      <?php echo csrf_field(); ?>
         <div class="form-group row">
            <div class="col-sm-0 mb-0 mb-sm-0">
            </div>
            <div class="col-sm-5">
            
                 <select class="form-control"  name=lista>
                 <?php $__currentLoopData = $listas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option  value=<?php echo e($l->id); ?> ><?php echo e($l->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <a href="#"  onclick="document.getElementById('lista_actualizacion_seleccion').submit();" class="btn btn-success btn-icon-split">
               <span class ="icon text-white-50">
                          <i class="fas fa-check-double"></i>
               </span>
               <span class="text">Ingresar</span>
              </a>
            </div>

            
            
        </div>
      
    </form>

            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyecto/gestion_stock/resources/views/lista_actualizacion_seleccion.blade.php ENDPATH**/ ?>